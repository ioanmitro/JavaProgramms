package trees;

public enum RedBlackColor { RED, BLACK };